<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/27 0027
 * Time: 下午 2:37
 */



include_once "./config.php" ;


include_once "./dbman.php" ;
/*
include_once "./classBack.php";
include_once "./classTool.php";
include_once "./classMySQL.php";*/



//添加句子


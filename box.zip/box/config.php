<?php
header("Content-type:text/html;charset=". "UTF-8");//字符编码设置
$server_dir = $_SERVER['DOCUMENT_ROOT']."/box";

define('ROOT_DIR',$_SERVER['DOCUMENT_ROOT']."/box");

define('CHARSET_DEF',"UTF-8");

define("CHARSET_SQL","utf8");


//在这里配置数据库参数
define("MYSQL_DB_ADDR","127.0.0.1:3306");
define("MYSQL_DB_USER","root");
define("MYSQL_DB_PWS","welldone");
define("MYSQL_DB_NAME","b5");






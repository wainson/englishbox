<?php

include_once $_SERVER['DOCUMENT_ROOT'] . "/bao/page/config.php" ;

include_once dirname(__FILE__)."/classMySQL.php";




class classTool{

    function __construct()
    {

    }






    //执行SQL语句
    function exe_sql($sql,$param,$action){

        $mysql = new mysql();
        $rsp = null;
        if ($action==1){
            //GetData
            //返回array[]数组

            //echo ">>exec>>action=1";
            $rsp = $mysql->GetData($sql,$param);

        }elseif($action==0){
            //GetResult
            //返回：1/0
            //echo '>>exe_sql>>$action==0<br>';
            $rsp=$mysql->GetResult($sql,$param);
        }

        $mysql = null;
        return $rsp;

    }


    //解读json信息
    function  read_json(){



    }


    function now(){
       //return date('YmdHis',time());
        $mt = microtime();
        list($usec, $sec) = explode(" ", $mt);
        $da = date('YmdHis',$sec);
        $msec = mb_substr($usec,2,4,'utf-8');
        return $da . $msec;
    }

    function date_time(){
        //return date('YmdHis',time());
        $mt = microtime();
        list($usec, $sec) = explode(" ", $mt);
        $da = date('Y-m-d H:i:s ',$sec);
        $msec = mb_substr($usec,2,4,'utf-8');
        return $da . $msec;
    }

    function yestd($num){

        $td = array();
        $td[0] = date('Ymd0000000000',time());
        $td[1] = date('Ymd2359599999',time());
        return $td[$num];

    }

    function today($num){

        $td = array();
        $td[0] = date('Ymd0000000000',time());
        $td[1] = date('Ymd2359599999',time());
        return $td[$num];

    }

    function month($num){

        $td = array();
        $td[0] = date('Ymd0000000000',time());
        $td[1] = date('Ymd2359599999',time());
        return $td[$num];

    }



    /*
     * 将文件读入一个字符串变量
     * 成功返回：一个字符串
     * 失败返回：null
     */
    function read_file($file_path){

        if(file_exists($file_path)){
            $str = file_get_contents($file_path);//将整个文件内容读入到一个字符串中
            return $str;
        }else{
            return null;
        }
    }

    /*
     * 将错误写入数据库
     */
    function error_log($e){



    }



    function error_txt($text) {
        // $text=iconv("GBK", "UTF-8//IGNORE", $text);
        //$text = characet ( $text );

        //$class = get_called_class($this);

        file_put_contents ( "./log.txt", $this->date_time() . "   " . $text . "\r\n", FILE_APPEND );
    }


    function __destruct()
    {

    }
}
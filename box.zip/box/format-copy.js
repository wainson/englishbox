


var cat_order = 0;

var dragStaus = 0;

var boxcount = 0;

// 定义常量吸附范围
const RANGE = 50;
var dragging = false;
var boxX, boxY, mouseX, mouseY, offsetX, offsetY;

/*

//DcumentReady
$(document).ready(function () {
    //alert("ok");
    $(".va").css('backgroundColor',"#00a5e0");

    dragging = false;

});


//$(".vac_word").mousedown(function (e) {
$(document).on('mousedown','.vac_word',function (e) {
    var obj = $(this).get(0);
    //console.log(obj.innerText);
    down(e,obj);

});

//$(".vac_word").mousemove(function (e) {
$(document).on('mousemove','.vac_word',function (e) {

        var obj = $(this).get(0);
        move(e,obj);

});


//$("vb_command").on("mouseup",".vac_word",function (e) {
//$(document).on('mousedown','.vac_word',function () {
//$(".vac_word").mouseup(function (e) {
$(document).on('mouseup','.vac_word',function (e) {
    up(e);

});
*/








$('.va_textinput').find('textarea').on('input change',function(e){
//$(document).on("change",'#sentence_input',function (e) {

        //alert("ok");

    //$(".col_box").remove();
    $(".vac_word").remove();

    var Words = $('#sentence_input').val();
    var WordsArr = Words.trim().split(" ");

    for(var i = 0 ; i < WordsArr.length; i ++){
        var Word = WordsArr[i];
        //根据当前字体多少，动态产生相应宽度的DIV容器
        var fontWidth = 50;
        var divWidth = fontWidth * Word.length;


        //$(".vac_word").remove();

        NewWord(divWidth,60,Word,i);

    }

   /* var $tar = $(document.getElementById("b3"));
    $tar.css('backgroundColor',"#CC3333")*/



});




////////////////////////////////////////////////////////////////////////////////////////////////////
// 各种功能函数
///////////////////////////////////////////////////////////////////////////////////////////////////

//插入一段div
function NewWord(divWidth,divHigh,word,id) {

    var div = "";
    var elm = [];

    /*elm.push("<div class='col_box'  id='c" + id + "'    >\n");
    elm.push("      <div class='row_box'  id='r" + id + "'    >\n");

    elm.push("              <div class='word_single'  id='s" + id + "'   >\n");*/
/*    elm.push("                      <div class='edgebox' id='e" + id +     "'  >\n");
    //elm.push("                              <div class='cellboxtop' id='tl" + id +     "'   ></div>\n");
    elm.push("                              <div class='cellbox' id='ml" + id +     "'  ondragenter='dragEnter(event)' ondragleave='dragLeave(event)' ondragover='closeLink(event)' ></div>\n");
    elm.push("                              <div class='cellbox' id='bl" + id +     "'  ondragenter='dragEnter(event)' ondragleave='dragLeave(event)'  ondragover='closeLink(event)' ></div>\n");
    elm.push("                      </div>\n");*/

    elm.push("                      <div class='vac_word' id='w" + id +  "' >" + word + "</div>\n");

/*    elm.push("                      <div class='edgebox' id='d" + id +     "' >\n");
    //elm.push("                              <div class='cellboxtop' id='tr" + id +     "'  ></div>\n");
    elm.push("                              <div class='cellbox' id='mr" + id +     "'  ondragenter='dragEnter(event)' ondragleave='dragLeave(event)' ondragover='closeLink(event)' ></div>\n");
    elm.push("                              <div class='cellbox' id='br" + id +     "'  ondragenter='dragEnter(event)' ondragleave='dragLeave(event)' ondragover='closeLink(event)' ></div>\n");
    elm.push("                      </div>\n");*/
    /*elm.push("              </div>\n");*/

    elm.push("      </div>\n");
    elm.push("</div>\n");

    for (var i = 0; i < elm.length; i++) {
        div = div + elm[i];
    }

    $('#vb_command').append(div);

    //$(document.getElementById("w"+id)).offset({top:300,left: divWidth + 20 });




    boxcount += 1;

}


// 鼠标按下后的函数,e为事件对象
function down(e,obj) {
    dragging = true;

    // 获取元素所在的坐标
    boxX = obj.offsetLeft;
    boxY = obj.offsetTop;
    // 获取鼠标所在的坐标
    mouseX = parseInt(getMouseXY(e).x);
    mouseY = parseInt(getMouseXY(e).y);
    // 鼠标相对元素左和上边缘的坐标
    offsetX = mouseX - boxX;
    offsetY = mouseY - boxY;
    //$("#box").text(offsetX + "/" + offsetY);
    //console.log("mouseXY:" + mouseX + "/" + mouseY);
    //console.log("offsetXY:" + offsetX + "/" + offsetY);
}

// 鼠标移动调用的函数
function move(e,obj){
    if (dragging) {
        // 获取移动后的元素的坐标
        var x = getMouseXY(e).x - offsetX;
        var y = getMouseXY(e).y - offsetY;
        // 计算可移动位置的大小， 保证元素不会超过可移动范围
        // 此处就是父元素的宽度减去子元素宽度
        /*var width = box1.clientWidth - box.offsetWidth;
        var height = box1.clientHeight - box.offsetHeight;
        // min方法保证不会超过右边界，max保证不会超过左边界
        x = Math.min(Math.max(0, x), width);
        y = Math.min(Math.max(0, y), height);
        // 磁性吸附部分
        if (x < RANGE) {x = 0}
        if (width - x < RANGE) {x = width}
        if (y < RANGE) {y = 0}
        if (height - y < RANGE) {y = height}*/
        // 给元素及时定位
        obj.style.left = x + 'px';
        obj.style.top = y + 'px'
    }
}

// 释放鼠标的函数
function up(e){
    dragging = false
}


// 函数用于获取鼠标的位置
function getMouseXY(e){
    var x = 0, y = 0;
    e = e || window.event;

    if (e.pageX) {
        x = e.pageX;
        y = e.pageY
    } else {
        x = e.clientX + document.body.scrollLeft - document.body.clientLeft;
        y = e.clientY + document.body.scrollTop - document.body.clientTop
    }
    return {
        x: x,
        y: y
    }
}





function GetNum(sid) {
    var RegNom = new RegExp("[^0-9]","g");
    return  sid.replace(RegNom,"");
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// 各种事件
////////////////////////////////////////////////////////////////////////////////////////////////////

function closeLink(ev){
    ev.preventDefault();
}


function dragEnter(ev) {

    var id = ev.target.id;
    var num = GetNum(id);
    var $single = $(document.getElementById("s" + num));
    var $tar = $single.find(".cellbox");
    console.log(num);
    $tar.css('backgroundColor',"darkgray");
    $tar.css({ opacity: 0.8 });


    //动态产生四个方格，代表4个位置


}

function dragLeave(ev) {
    var id = ev.target.id;
    var num = GetNum(id);
    var $single = $(document.getElementById("s" + num));
    var $tar = $single.find(".cellbox");
    //$tar.css('backgroundColor', "#4cae4c");

    $tar.css('backgroundColor',"transparent");
    $tar.css({ opacity: 1 });

    /*var $edg = $single.find(".edgebox");
    $tar.width(40);*/

/*    $(document.getElementById("s"+num)).css("display","flex");
    $(document.getElementById("r"+num)).css("display","flex");
    $(document.getElementById("c"+num)).css("display","flex");*/

}


function drag(ev){
    ev.dataTransfer.setData("Text",ev.target.id);
    //ev.dataTransfer.setData("Text",ev.target.parentNode.id);
    dragStaus = 1;
}

function drop(ev){
    ev.preventDefault();
    var data=ev.dataTransfer.getData("Text");
    //ev.target.appendChild(document.getElementById(data))

    //alert(data);

    //被捉住的cat
    var $cat = $(document.getElementById(data));
    //$cat.css("visibility","hidden");


    $cat.css("order",cat_order);

    var    id = ev.target.id;

    console.log("id: " + id);


    var RegNum=new RegExp("\\d","g");

    var RegNom=new RegExp("[^0-9]","g");

    var  nid = id.replace(RegNom,"");
/*            nid = id.replace("bl","");
            nid = id.replace("mr","");
            nid = id.replace("br","");*/

    console.log( "number_id: " + nid);

     var pid = id.replace(nid,"");

     console.log( "position_id: " + pid);

     //目标容器id
     var tid = "";
     if(pid === "ml" || pid === "mr"){
         tid = "r" + nid
     }else if(pid === "bl" || pid === "br"){
         tid = "c" + nid
     }


     console.log("target_id: " + tid);

    //console.log(ev.target);
    //console.log(ev.target.id);

    var $tar = $(document.getElementById(tid));
    $tar.css('backgroundColor',"#CC3333");



    //调整顺序

    //调整容器的宽度

    //投放目的地target
   // var $tar = $(document.getElementById(ev.target));

    //$tar.appendChild(document.getElementById(data));

    $tar.append($cat);


    cat_order+=1;

    dragStaus = 0;

}





















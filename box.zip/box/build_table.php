<?php

include_once $_SERVER['DOCUMENT_ROOT'] . "/box/config.php" ;


//build_db($db_param,"b5");




drop_table();

build_table();



function build_db(){

    $server     = MYSQL_DB_ADDR;
    $user       = MYSQL_DB_USER;
    $pws        = MYSQL_DB_PWS;
    $db_name    = MYSQL_DB_NAME;

    $conn = new mysqli($server, $user, $pws);


    if ($conn->connect_error) {
        die("连接失败: " . $conn->connect_error);
    }
    else
    {
        //如果存在数据库就把它删除
        $conn->query("drop database if exists ".$db_name);

        //创建数据库
        $sql_build_db = "CREATE DATABASE ".$db_name;
        if ($conn->query($sql_build_db) == TRUE) {


        } else {
            echo "Error creating database: " . $conn->error;
        }

        $conn->close();

    }

}

function build_table()
{

    $sql_build_table = array();

    //sentence
    $sql_build_table[0]="
            CREATE TABLE box_st
            (
                id          bigint(12)    AUTO_INCREMENT PRIMARY KEY ,
                boid        int(8)    ,
                caid        int(8)    ,
                en          text        CHARACTER SET ". CHARSET_SQL .",
                cn          text        CHARACTER SET ". CHARSET_SQL .",
                fs          int(3)  default 30 ,
                time        bigint(18)  
            )
            engine=MyISAM  DEFAULT CHARSET=" . CHARSET_SQL;


    //words
    $sql_build_table[1]="
            CREATE TABLE box_wd
            (
                id        bigint(12)      AUTO_INCREMENT PRIMARY KEY ,
                stid      int(8)         ,
                oder      int(3)         ,
                en        VARCHAR(200)   CHARACTER SET ". CHARSET_SQL .",
                cn        VARCHAR(100)   CHARACTER SET ". CHARSET_SQL .",
                x         VARCHAR(10)   ,
                y         VARCHAR(10)   ,
                co        int(3)        default 0,
                bc        int(3)         default 0,
                time      bigint(18)         
            )
            engine=MyISAM  DEFAULT CHARSET=" . CHARSET_SQL;


    $add_idx = array();
    array_push($add_idx,"CREATE          INDEX boid    ON box_st (boid)");
    array_push($add_idx,"CREATE          INDEX caid    ON box_st (caid)");
    array_push($add_idx,"CREATE          INDEX time    ON box_st (time)");

    array_push($add_idx,"CREATE          INDEX stid     ON box_wd (stid)");
    array_push($add_idx,"CREATE          INDEX time     ON box_wd (time)");



    $server     = MYSQL_DB_ADDR;
    $user       = MYSQL_DB_USER;
    $pws        = MYSQL_DB_PWS;
    $db_name    = MYSQL_DB_NAME;


    //取得连接
    $conn = new mysqli($server, $user, $pws, $db_name);
    if ($conn->connect_error) {
        die("连接失败: " . $conn->connect_error);
    }
    else {


        $cs = count($sql_build_table);
        for ($t = 0; $t < $cs; $t++) {

            if ($conn->query($sql_build_table[$t]) === TRUE) {
                //echo $t . ":". $sql_build_table[$t] . "<br>");
                echo "successfully<br>";
            } else {
                echo $sql_build_table[$t] . "<br>";
                echo "创建数据表错误: " . $conn->error;
            }
            echo "<br>";
        }

        $cd = count($add_idx);
        for ($i = 0; $i < $cd; $i++) {

            if ($conn->query($add_idx[$i]) === TRUE) {
                echo $i . ":". $add_idx[$i] . "<br>";
                echo "successfully<br>";
            } else {
                echo $add_idx[$i] . "<br>";
                echo "创建数据表错误: " . $conn->error;
            }
            echo "<br>";
        }


    }









}

function drop_table()
{

    $table = array('box_st','box_wd');

    //order
    $sql_drop_table="drop table ";


    $svr    = MYSQL_DB_ADDR;
    $user   = MYSQL_DB_USER;
    $pws    = MYSQL_DB_PWS;
    $name   = MYSQL_DB_NAME;


    //重新取得连接
    $conn = new mysqli($svr, $user, $pws, $name);
    if ($conn->connect_error) {
        die("连接失败: " . $conn->connect_error);
    }
    else {

        $cs = count($table);
        for ($t = 0; $t < $cs; $t++) {

            if ($conn->query($sql_drop_table.$table[$t]) === TRUE) {
                echo $t . ":". $sql_drop_table.$table[$t]. "<br>";
                echo "successfully<br>";
            } else {

                echo "drop_table错误: " . $conn->error;
            }
            echo "<br>";
        }
    }









}

/**
 * 根据SQL执行查询，返回json格式的数据
 * @param $db_param，是一个包含数据库登陆信息的数组
 * @param $SQL  是一个字符串格式的SQL语句
 * @return json
 */
function query($db_param,$SQL){

    $db = new mysqli($db_param['addr'],$db_param['user'],$db_param['pws'],$db_param['name']);

    $db->select_db($db_param['name']);

    $result = $db->query($SQL);

    $sum_rows = $result->num_rows;

    $jarr = array();
    //echo $sum_rows.'<br />';

    for ($i=0;$i<$sum_rows;$i++){

        //$cur_row = $result->fetch_row($result);
        $cur_row = $result->fetch_assoc();
        $sum_columns = count($cur_row);
        /**
        for ($c=0;$c<$sum_columns;$c++){
        echo $cur_row[$c];
        }
        echo '<br/>';
         * */
        array_push($jarr,$cur_row);
    }

    $str=json_encode($jarr);
    //echo $str;
    $arr=json_decode($str);//再进行json解码
    //echo '解码后的数组：<br>';
    //print_r($arr);//打印解码后的数组，数据存储在对象数组中
    return $arr;
}





<?php

include_once  "./config.php" ;


class mysql
{
    protected $mysql;
    private $connect_errno;
    function __construct()
    {
        //echo "已进入构造函数内";
        //Get MySQL config values from config.ini file
        //$dir = $_SERVER['DOCUMENT_ROOT']."/bao";

        //if($config = parse_ini_file($dir."/config/config.ini"))
        //{
            //$config = parse_ini_file("./config/config.ini");
            //echo "已找到config.ini文件";
            // Obtener los valores del fichero de configuración config.ini
            $svr    = MYSQL_DB_ADDR;
            $user   = MYSQL_DB_USER;
            $pws    = MYSQL_DB_PWS;
            $name   = MYSQL_DB_NAME;

//            $t = new classTool();
//            $t->error_txt("class mysql >> __construct");
//            $t->error_txt(">> \$svr >> $svr");
//            $t->error_txt(">> \$user >> $user");
//            $t->error_txt(">> \$pws >> $pws");
//            $t->error_txt(">> \$name >> $name");

//            $svr    = $db_param['addr'] ;
//            $user   = $db_param['user'];
//            $pws    = $db_param['pws'] ;
//            $name   = $db_param['name'];

            //Connection between a database and php
            try{
                $this->mysql = new mysqli($svr, $user, $pws, $name);
                //$this->mysql->character_set_name(CHARSET_DEF);
                //$this->mysql->set_charset(CHARSET_GBK);
                $this->mysql->query("SET NAMES " .  CHARSET_SQL);

            }catch(Exception $e){
                $this->connect_errno=$e->getCode();
                echo $e->getCode();
                echo $this->connect_errno;
            }
        //}
    }

    //将查询结果返回到一个数组里面
    //查询正确执行，但没有结果，返回的是null
    function GetData($query,$arr_param)
    {
        //$t = new classTool();
        //$t->error_txt($query);


        //echo ">>GetData";
        $array = NULL;
        if(!$this->mysql->connect_errno)
        {
            $stmt = $this->GetSTMT($query,$arr_param);



            try
            {
                //echo ">>try";
                if($stmt != NULL)
                {
                    //echo ">>stmt not null";
                    if($stmt->execute())
                    {
                        //Obtener resultados
                        //echo ">>execute()";
                        //echo "<br>".$stmt->errno;
                        $stmt->store_result();
                        $variables = array();
                        $data = array();
                        $meta = $stmt->result_metadata();
                        while($field = $meta->fetch_field())
                        {
                            $variables[] = &$data[$field->name];
                        }
                        call_user_func_array(array($stmt, 'bind_result'), $variables);
                        $i=0;
                        while($stmt->fetch())
                        {
                            $array[$i] = array();
                            foreach($data as $k=>$v)
                                $array[$i][$k] = $v;
                            $i++;
                        }
                        $stmt->close();
                    }
                }
            }catch(Exception $e){
                $array = FALSE;

            }
        }
        return $array;
    }

    function GetSTMT($query,$arr_param)
    {

        try
        {
            //带？通配符的SQL语句
            $stmt = $this->mysql->prepare($query);
            //echo 'GetSTMT>>$stmt>>$query:<br>';
            //echo "$query<br>";
            //实例化一个反射类，以类名mysqli_stmt，作为输入参数，
            //最终实反射了PHP内置类：mysqli_stmt
            //用人话来讲是，取得了mysqli_stmt类的方法，属性
            //mysqli_stmt类代表了一个prepared语句。
            //其中一个方法是绑定参数，bind_param
            //bind_param方法类似于.Net里面的string.format({0},var1)
            $ref = new ReflectionClass('mysqli_stmt');
            //echo ">>进入了GetSTMT";
            //var_dump($arr_param);
            //var_dump($stmt);
            //需要判断$stmt==false
            if(count($arr_param) != 0)
            {

                $method = $ref->getMethod('bind_param');
                $method->invokeArgs($stmt,$this->refValues($arr_param));
            }
        }catch(Exception $e){
            if($stmt != null)
            {
                $stmt->close();
            }
        }
        return $stmt;
    }

    //返回值：1代表执行SQL语句成功，0:代表执行失败
    //insert,update,drop,create等调此函数
    //上面这些语句执行后，只需要返回一个执行结果，
    //不像select语句需要返回数据
    function GetResult($query,$arr_param)
    {

        //$t = new classTool();
        //$t->error_txt("classMySQL.php > ");
        //var_dump($arr_param);
        $validation = 0;
        if(!$this->mysql->connect_errno)
        {
            //echo ">>GetResult";
            //$t->error_txt(">>GetResult ");
            try
            {
                //echo ">>try";
                //echo ">><br>$query<br>";
                //$t->error_txt(">>try ");
                $stmt = $this->GetSTMT($query,$arr_param);
                if($stmt != null)
                {
                    //echo '$stmt != null';
                    if($stmt->execute())
                    {

                        //echo '$stmt->execute()执行成功了';

                        //$validation = 1;

                        //$t->error_txt(">>\$stmt->execute()执行成功了");
                        $ar = $stmt->affected_rows;

                        if ($ar > 0){
                            $validation = 1;
                            //$t->error_txt(">>\$ar > 0");
                        }else{
                            $validation = 0;
                            //$t->error_txt(">>\$ar <= 0");
                        }

                        $stmt->close();

                    }else{
                        //执行失败
                        //echo '>>$stmt->execute()执行结果==false<br>';
                        //$t->error_txt(">>\$stmt->execute()执行结果==false");
                        $validation = 0;
                    }

                }

            }catch(Exception $e){
                $validation = 0;
                //echo "肯定发生了一个异常";

                //$t->error_txt(">>catch 异常 ");
                //$t->error_txt(">>$e");

            }
        }else{
            $no = $this->mysql->connect_errno;

            //$t->error_txt(">> connect_errno >> $no");

        }
        return $validation;
    }


    function refValues($arr){
        if (version_compare(PHP_VERSION, '5.3.0') >= 0) {
            $refs = array();
            foreach($arr as $key => $value)
                $refs[$key] = &$arr[$key];
            return $refs;
        }
        return $arr;
    }

    /*
     * 不通过STMT对象执行SQL语句
     */
    function LastID($TableName){



    }


    function Query($SQL){
        //echo $SQL;
        $m  = $this->mysql;

        $RSP =  $m->query($SQL);

        return $RSP;

        //var_dump( $RSP);
    }



    function __destruct()
    {
        $this->mysql->close();
        //echo ">>mysql>close";
    }


}

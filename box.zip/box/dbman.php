<?php

include_once "./config.php" ;
include_once "./classBack.php";
include_once "./classTool.php";
include_once "./classMySQL.php";

//echo wd_edit(1635,1,0,"周二");

//echo st_del(5);


/*echo wd_edit(1,"every","每",1,1);

return;*/



if(empty($_POST['data']) || $_POST['data'] == 'false') {

    $b = new classBack();

    $b->rsp_fail("缺少参数:data");

    exit();
}


/*$t = new classTool();
$t->error_txt("*************************************************");
$t->error_txt($_POST['data']);
$t->error_txt("*************************************************");*/




$data = json_decode($_POST['data']);
$op = $data->op;



if($op == "st_save"){
    $da = $data->da;
    $st = $da->st;
    $wd = $da->wd;
    st_save($st,$wd);

}else if($op == "st_list"){
    st_list();

}else if($op == "st_single"){
    $da=$data->da;
    $id = $da->id;

/*    $t = new classTool();
    $t->error_txt("id:" . $id);*/

    st_single($id);
}



function wd_add($stid, $oder,  $en, $cn, $x, $y,$co,$bc, $time){

    $mysql = new mysql();

    $rst = 0;

    $sql = "insert into box_wd(stid, oder,  en, cn, x, y,co,bc, time )VALUES (?,?,?,?,?,?,?,?,?)";

    /*$t = new classTool();
    $t->error_txt( "sql:" . $sql);*/

    $param = array('iissssiii',$stid, $oder,  $en, $cn, $x, $y, $co,$bc,$time);
    $rsp = $mysql->GetResult($sql,$param);

    if($rsp==1){
        $rst = 1;
    }

    $mysql = null;
    return $rst;
}

function wd_del($stid){

    $mysql = new mysql();

    $sql = "delete from box_wd where stid=?";
    $param = array('i',$stid);
    $rsp = $mysql->GetResult($sql,$param);

    $mysql = null;
    return $rsp;
}

/**
 * @param $stid
 * @param $c:color
 * @param $bc:backgroud-color
 * @param $cn:chinese
 */
function wd_edit($stid,$oder,$en,$cn,$x,$y,$co,$bc){

    $t = new classTool();
    $time = $t->now();

    //$t->error_txt($stid . "/" . $id . "/" . $en . "/" . $cn  . "/" .$x  . "/" .$y  . "/" .$co  . "/" .$bc."\n" );


    $mysql = new mysql();
    $sql = "update box_wd set x=?,y=?, co=?, bc=?, cn=? ,time=? where stid=? and oder=? and en=?";

    //$t->error_txt($sql);

    $param = array("ssiisiiis",$x,$y,$co,$bc,$cn,$time,$stid,$oder,$en);
    $rsp = $mysql->GetResult($sql,$param);
    if($rsp==1){
        $rst = 1;
    }else{
        $rst = 0;
    }


    //if($oder == 0 || $oder == 18){
        //$t->error_txt("单词:'".$en . "'的保存结果是:" . $rsp);
    //}

    $t = null;
    $mysql=null;
    return $rst;
}





function st_add($boid,$caid,$en,$cn,$fs,$time){
    $mysql = new mysql();

    $id = 0;

    $sql = "insert into box_st(boid, caid,  en, cn,fs, time )VALUES (?,?,?,?,?,?)";
    $param = array('iissii',$boid,$caid,$en,$cn,$fs,$time);
    $rsp = $mysql->GetResult($sql,$param);

    if($rsp==1){

        //查找
        $sql = "SELECT id FROM box_st WHERE en=? AND time=?";
        $param = array("si",$en,$time);
        $rsp = $mysql->GetData($sql,$param);
        if(count($rsp) > 0) {
            $id = implode($rsp[0]);
        }
    }

    $mysql = null;
    return $id;
}


function st_del($stid){
    $mysql = new mysql();

    $sql = "delete from box_st where id=?";
    $param = array('i',$stid);
    $rsp = $mysql->GetResult($sql,$param);

    $mysql = null;
    return $rsp;
}




function st_edit($stid, $stcn,$fs,$time){
    $t = new classTool();
    $time = $t->now();

    $mysql = new mysql();
    $sql = "update box_st set cn=?,fs=? where id=?";
    $param = array("sii",$stcn,$fs,$stid);
    $rsp = $mysql->GetResult($sql,$param);
    if($rsp==1){
        $rst = 1;
    }else{
        $rst = 0;
    }
    $t = null;
    $mysql=null;
    return $rst;
}




function st_repeat($en){

    $mysql = new mysql();

    $sql = "SELECT id FROM box_st WHERE en=?";

    $param = array("s",$en);

    $rsp = $mysql->GetData($sql,$param);

    if(count($rsp) > 0){

        if(implode($rsp[0])==null){
            $rst = 0;
        }else{
            $rst = 1;
        }

    }else{
        $rst = 0;
    }

    $mysql = null;

    return $rst;

}


function st_id($en){
    $mysql = new mysql();

    $sql = "SELECT id FROM box_st WHERE en=?";

    $param = array("s",$en);

    $rsp = $mysql->GetData($sql,$param);
    //var_dump($rsp);
    $id = 0;
    if(count($rsp) > 0) {

        if (implode($rsp[0]) != null) {
            $id = implode($rsp[0]);
        }
    }

    $mysql = null;

    return $id;

}

function st_single($stid){

    $mysql = new mysql();
    $b = new classBack();
    try{
        //st
        $s1 = "SELECT en,cn,fs FROM box_st WHERE id=? ORDER BY id ASC";
        $p1 = array("i",$stid);
        $st = $mysql->GetData($s1,$p1);

        //wd
        $s1 = "SELECT oder,en,cn,x,y,co,bc FROM box_wd WHERE stid=? ORDER BY stid ASC";
        $p1 = array("i",$stid);
        $WDA = [];
        $WDA = $mysql->GetData($s1,$p1);

        $da = (object)[];
        $da->st = $st;
        $da->wd = $WDA;
        $b->rsp_success($da);

        /*$t = new classTool();
        $t->error_txt(json_encode($da));*/

    }catch (Exception $ex){
        $b->rsp_fail($ex->getMessage());
    }

    $mysql = null;
    $b = null;
    return;
}



function st_list(){
    $b = new classBack();
    try{
        $mysql = new mysql();
        $s1 = "SELECT id,en,cn,fs FROM box_st where en IS not null  ORDER BY id ASC";
        //$p1 = array("i","");
        $list = $mysql->GetData($s1,null);
        $b->rsp_success($list);

    }catch (Exception $ex){
        $b->rsp_fail($ex->getMessage());
    }


    $b = null;
    $mysql = null;
    return;
}

function st_save($st,$wd){

    $b = new classBack();
    try{
        $sten = $st->en;
        $stcn = $st->cn;
        $fs   = $st->fs;
        $t = new classTool();
        $now = $t->now();

/*        $t->error_txt("sten:" . $sten);
        $t->error_txt("stcn:" . $stcn);
        $t->error_txt("stfs:" . $fs);*/


        if(st_repeat($sten)==0){
            $stid = st_add(1,1,$sten,$stcn,$fs,$now);
            //$t->error_txt("stid:" . $stid);
            if($stid == 0){

                $b->rsp_fail("数据没有被服务器保存");
                $b = null;
                $t = null;
                return;
            }


            $succ = 0;
            for($i = 0 ; $i < count($wd) ; $i++) {
                $word = $wd[$i];
                $n = $word->n;
                $e = $word->e;
                $c = $word->c;
                $x = $word->x;
                $y = $word->y;
                $co = $word->co;
                $bc = $word->bc;
                if($e==" ") continue;
                $succ += wd_add($stid,$n,$e,$c,$x,$y,$co,$bc,$now);

            }

            //$t->error_txt("成功数量:" . $succ);
            //$t->error_txt("单词总数:" . count($wd));

            if($succ < count($wd)){
                $b->rsp_fail("单词数据没有被服务器保存");
                st_del($stid);
            }


        }else{
            $stid = st_id($sten);

            //修改stcn
            st_edit($stid,$stcn,$fs,$now);


            for($i = 0 ; $i < count($wd) ; $i++) {
                $word = $wd[$i];
                $id = $word->n;
                $en = $word->e;
                $cn = $word->c;
                $x  = $word->x;
                $y  = $word->y;
                $co = $word->co;
                $bc = $word->bc;
                if($en==" ") continue;
                wd_edit($stid,$id,$en,$cn,$x,$y,$co,$bc);
            }

        }


        $b->rsp_success("");

    }catch (Exception $ex){
        $b->rsp_fail($ex->getMessage());
    }


    $b = null;
    $t = null;
    return;
}
<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/27 0027
 * Time: 上午 12:13
 */


/*
 * RSP = respond
 *
 */
class classBack
{

    function op($result,$msg,$data){
        $op = (object)[];
        $op -> result   = $result;
        $op -> msg      = $msg;
        $op -> data     = $data;
        return $op;
    }





    function  rsp_fail($msg){

        /*$t = new classTool();
        $t->error_txt("  >> classBack.php >> resp_fail() >> msg >>");
        $t->error_txt("  >> " . $msg);
        $t = null;*/

        $op = $this->op("fail",$msg,null);

        echo json_encode($op,320);

        return;
    }




    function rsp_success($data){

        //$t = new classTool();
        //$t->error_txt("success");
        //$t->error_txt("classBack.php >> rsp_success() >> json_encode(\$feedback) >>");
        //$t->error_txt( ">> " . json_encode($feedback,256));
        //$t = null;

        $op = $this->op("success","操作成功",$data);

        echo json_encode($op,320);

        return;
    }




}
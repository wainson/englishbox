



var HowManyWords = 0;

var coor = [];


var DownloadButtonStatus = 0;

//SenTence Array:里面装的是句子
//数组对应的index不是连续的，正好是句子在数据库中的唯一id
var STA = [];


//存放单词的中文意思，
var CNA = [];

//VOCAbulary Array:词汇数组
var voca = [];

//ColOr Array:单个词汇的存放颜色
//BackgroundColorArray:背景颜色数组
var COA = [];
var BCA = [];

var wd_fontsize = [];

var panel_status = 0;

//当前句子id
var st_cur = 0;

//当前单词id
var wd_num = 0;

//将单词在一行或多行里面打散
//用此变量累计X座标
var px_count = 100;
var py_count = 100;
var line_count = 0;



var color_pen = [];
    color_pen[0] = "transparent";
    color_pen[1] = "#F54296";
    color_pen[2] = "#FFDD11";
    color_pen[3] = "#4D90FE";
    color_pen[4] = "#2FBB4F";
    color_pen[5] = "#FF6600";
    color_pen[6] = "#CC99CC";
    color_pen[7] = "#8877DD";
    color_pen[8] = "#F6F6EF";


function Index() {

    /*******************************************************
     * 功能事件
     *******************************************************/
    /*
        DcumentReady

        字体调大

        字体调小

        录入句子

        列出所有句子

        载入指定句子

        保存当前句子

        弹出控制面板
            点击相应的颜色
            录入单词的中文意思

        退出控制面板






    */


    /*******************************************************
     * 功能函数
     *******************************************************/
    /*

        添加单词控制面板DIV

        添加句子列表DIV

        展示单词
            加载单词DIV


        截取数字

        收集单词数据

    */

}











//DcumentReady
$(document).ready(function () {
    //alert("ok");
    $(".va").css('backgroundColor',"#00a5e0");


});


//录入单词的中文意思
$(document).on("input propertychange","#vocn",function(){
    CNA[wd_num] = $("#vocn").val();

    /*console.log($("#vocn").val());
    console.log(CNA[wd_num]);*/

});


//color_pan
//点击相应的颜色
$(document).on("mousedown",".color_pan",function () {

    var id = $(this).prop("id");

    //0 - 6 代表7种颜色
    var num = GetNum(id);


/*    console.log("id:" + id);
    console.log("num" + num);*/

    //console.log(color_pen[num]);

    //将相应的单词填充上颜色
    $(document.getElementById("w" + wd_num)).css("color",color_pen[num]);
    $(document.getElementById("p" + wd_num)).css("color",color_pen[num]);

    COA[wd_num] = parseInt(num);
    BCA[wd_num] = 0
    /*console.log(COA[wd_num]);*/

});





//退出控制面板
$(document).on("mousedown","#close",function () {

    panel_status = 0;
    $("#panel").remove();

});



//弹出控制面板
$(document).on("mousedown",".vac_panel",function () {

    if (panel_status == 1){
        $("#panel").remove();
        panel_status = 0;
        return;
    }

    panel_status = 1;
    var id = $(this).prop("id");

    var num = GetNum(id);

    wd_num = num;


    //console.log("id:" + id);
    //console.log("num:" + num);

    //$( "#dialog" ).dialog();

    var unit = document.getElementById("u" + num);

    var $uni = $(document.getElementById("u" + num));

    var ux = unit.style.left;
    var uy = parseFloat(unit.style.top , 10);

    //var uh = parseFloat(unit.style.height , 10);

    var uh = parseInt($uni.css("height"),10) ;

    //console.log("uy:" + uy);
    //console.log("uh:" + uh);

    var ty = ( uy + uh + 2 )  + "px";

    //console.log("ty:" + ty);


    var word = $(document.getElementById("w"+num)).text();

    ShowPanel(word,num,ux,ty);

});



//录入句子
$('.va_textinput').find('#sentence_input').on('input change',function(e){
//$(document).on("change",'#sentence_input',function (e) {

        //alert("ok");

    //新添加的单词需要left和top方向定位，需要用到这两个公共变量
    line_count = 0;
    px_count = 100;
    py_count = 0;


    $(".word_unit").remove();
    $(".vac_word").remove();
    $(".vac_panel").remove();

    //清空中文，color,background-color 这三个Array
    CNA = [];
    COA = [];
    BCA = [];

    var st = $('#sentence_input').val();
    var WordsArr = st.trim().split(/[,. ]/);

    HowManyWords = WordsArr.length - 1;

    for(var i = 0 ; i < WordsArr.length; i ++){

        //按英式空格分离出单词，带点标符号
        var Word = WordsArr[i];

        //根据当前字体多少，动态产生相应宽度的DIV容器
        var fontWidth = 50;
        var divWidth = fontWidth * Word.length;


        //$(".vac_word").remove();

        NewWord(divWidth,60,Word,i);


        //绑定

        var $tar = $(document.getElementById("u" + i));
        $tar.draggable({ grid: [ 20, 20 ] });
        //$tar.draggable({ snap: true });

    }

/*   var $tar = $(document.getElementById("b3"));
    $tar.css('backgroundColor',"#CC3333")*/

});








////////////////////////////////////////////////////////////////////////////////////////////////////
// 各种事件
////////////////////////////////////////////////////////////////////////////////////////////////////

//字体调大
$(document).on("mousedown","#FontSize1",function () {

    //获取para的字体大小
    var thisEle = $(".vac_word").css("font-size");

    //parseFloat的第二个参数表示转化的进制，10就表示转为10进制
    var FontSize = parseFloat(thisEle , 10);

    FontSize+=2;

    //设置para的字体大小
    $(".vac_word").css("font-size",  FontSize + "px" );
    $(".vac_panel").css("font-size",  FontSize + "px" );

    wd_fontsize[st_cur] = FontSize

});

//字体调小
$(document).on("mousedown","#FontSize0",function () {

    //获取para的字体大小
    var thisEle = $(".vac_word").css("font-size");

    //parseFloat的第二个参数表示转化的进制，10就表示转为10进制
    var FontSize = parseFloat(thisEle , 10);

    FontSize -= 2;

    //设置para的字体大小
    $(".vac_word").css("font-size",  FontSize + "px" );
    $(".vac_panel").css("font-size",  FontSize + "px" );
    wd_fontsize[st_cur] = FontSize

});



//载入指定句子
$(document).on("mousedown",".st_list_body",function () {

    //新添加的单词需要left和top方向定位，需要用到这两个公共变量
    line_count = 0;
    px_count = 0;




    var id = $(this).prop("id");

    var num = GetNum(id);

    st_cur = num;

    //console.log(STA[num].en);

    //用id向服务器请求座标数据


    var da = new Object();
        da.id = num;

    var opda = new Object();
    opda.op = "st_single";
    opda.da = da;

    //console.log(JSON.stringify(opda));


    $.ajax({
        url:'./dbman.php',
        type:'post',
        data:{data:JSON.stringify(opda)},
        dataType:'json',
        //contentType: "application/x-www-form-urlencoded; charset=utf-8",
        success:function(rsp){

            //console.log(rsp);
            try{
                if(rsp.result === "success"){

                    //把数据显示到黑板

                    ShowWords(rsp.data);


                }else{
                    alert("服务器返回失败，原因:" + rsp.msg)
                }
            }catch(err){
                alert("解析数据失败:" + err.toString())
            }

        },
        error:function(rsp){
            //console.log(rsp);
            alert("失败");
        }
    });



});



//保存当前句子
$(document).on("mousedown","#Save",function () {


    var st = new Object();
        st.en = $('#sentence_input').val();
        st.cn = $('#st_cn').val();
        if(wd_fontsize[st_cur] == null){
            st.fs = 30;
        }else{
            st.fs = wd_fontsize[st_cur];
        }


    //把参数打包成json格式字符串
    var da = new Object();
        da.st      = st;
        da.wd      = GetAllWords();

    var op = "st_save";

    var opda = new Object();
        opda.op = op;
        opda.da = da;

        //console.log(JSON.stringify(opda));


    $.ajax({
        url:'./dbman.php',
        type:'post',
        data:{data:JSON.stringify(opda)},
        dataType:'json',
        //contentType: "application/x-www-form-urlencoded; charset=utf-8",
        success:function(rsp){

            //console.log(rsp);
            try{
                if(rsp.result === "success"){

                    alert("保存成功");

                }else{
                    alert("服务器返回失败，原因:" + rsp.msg)
                }
            }catch(err){
                alert("解析数据失败:" + err.toString())
            }

        },
        error:function(rsp){
            //console.log(rsp);
            alert("失败");
        }
    });
});

//列出所有句子
$(document).on("mousedown","#List",function () {


    //如果listbox处于隐藏状态，点击按钮后显示，接着下载数据
    //再次点击按钮后，listbox隐藏，然后退出
    if(DownloadButtonStatus === 0){
        DownloadButtonStatus = 1;
        $("#listbox").css("visibility","visible");
        $("#listbox").css("z-index",10);
        $("#List").html("close");

    }else{
        DownloadButtonStatus = 0;
        $("#listbox").css("visibility","hidden");
        $("#listbox").css("z-index",-10);
        $(".st_list").remove();
        $("#List").html("List");
        return;
    }




    //动记添加
    /*for(var i = 0 ; i < 20; i ++){
        var st = "live is full of disappointment.live is full of disappointment.";
        //NewList(i, st.substring(0,60));
        NewList(i, st);
    }*/


    //return;

    var opda = new Object();
        opda.op = "st_list";

    $.ajax({
        url:'./dbman.php',
        type:'post',
        data:{data:JSON.stringify(opda)},
        dataType:'json',
        //contentType: "application/x-www-form-urlencoded; charset=utf-8",
        success:function(rsp){

            //console.log(rsp);
            try{

                if(rsp.result === "success"){

                    //STA = rsp.data;

                    if(rsp.data == null){
                        return;
                    }

                    for(var a = 0 ; a < rsp.data.length; a++){
                        //if(rsp.data.en != null){
                            STA[rsp.data[a].id] = rsp.data[a];
                            //console.log(rsp.data[a].id);
                        //}
                    }


                    for(var i = STA.length ; i >=0 ; i--){
                        var cst = STA[i];
                        if( cst == null || cst.en == null) continue;
                        var id = cst.id;
                        //var en = cst.en;
                        var en = cst.en.substring(0,60);

                        wd_fontsize[id] = cst.fs;

                        NewList(id,en);
                    }

                }else{
                    alert("服务器返回失败，原因:" + rsp.msg)
                }
            }catch(err){
                alert("解析数据失败:" + err.toString())
            }

        },
        error:function(rsp){
            alert("失败");
        }
    });

});

////////////////////////////////////////////////////////////////////////////////////////////////////
// 各种功能函数
///////////////////////////////////////////////////////////////////////////////////////////////////

//添加单词控制面板DIV
function ShowPanel(word,id,x,y) {


        $(".panel_word").remove();

        var div = "";
        var elm = [];

        elm.push("<div class='panel_word' id='panel' >\n");

        elm.push("  <div class='panel_close' id='plo" + id +  "' >\n");
        elm.push("      <div id='close'>x</div>\n");
        elm.push("  </div>\n");

        elm.push("  <div class='panel_color' id='plc" + id +  "' >\n");

        elm.push("  </div>\n");

        elm.push("  <div class='panel_cn' id='plcn" + id +  "' >\n");
        elm.push("      <span style='width: 60px;font-size: 20px'>中文:</span><textarea class='panel_in' id='vocn' ></textarea>\n");
        elm.push("  </div>\n");

        elm.push("</div>\n");

        for (var i = 0; i < elm.length; i++) {
            div = div + elm[i];
        }

        $('#vb_command').append(div);

        div = "";
        //添加7个小正方形DIV，代表7种颜色
        for (var i = 0; i < 9; i++) {
            div = div + "      <div class='color_pan' id='cp" + i +  "' >c</div>\n";
        }

        $(document.getElementById("plc"+id)).append(div);

        //修改CSS
        for (var i = 0; i < 9; i++) {
            var cp = document.getElementById("cp" + i);
                cp.style.backgroundColor = color_pen[i];
                cp.style.color = "transparent";
        }

        $("#cp0").css("backgroundColor","white"); //设置透明度
        $("#cp0").css("opacity","0.06"); //设置透明度

        //$(document.getElementById("w"+id)).offset({top:300,left: divWidth + 20 });

        var tar = document.getElementById("panel");
            tar.style.left = x;
            tar.style.top = y;


        //中文意思
        $("#vocn").val(CNA[id]);


        //添加对齐到网格
        var $tar = $(document.getElementById("panel"));
            $tar.draggable({ snap: true });


}


function AddColorRow(tar,ascii,id) {
    var div = "";
    var elm = [];
    elm.push("      <div class='color_row' id='plc" + String.fromCharCode(ascii) + id +  "' ><div>\n");

    for (var i = 0; i < elm.length; i++) {
        div = div + elm[i];
    }

}


//加载单词DIV
function NewWord(divWidth,divHigh,word,id) {

    var div = "";
    var elm = [];


    var wa = word.substring(0,word.length-1);
    var wz = word.replace(wa,"");

    /*console.log("wd:" + word);
    console.log("wa:" + wa);
    console.log("wz:" + wz);
    console.log("--------------------");*/

    elm.push("<div class='word_unit' id='u" + id +  "' >\n");
    elm.push("  <div class='vac_word' id='w" + id +  "' title='" + word + "'>" + wa + "</div>\n");
    elm.push("  <div class='vac_panel' id='p" + id +  "' >" + wz + "</div>\n");
    elm.push("</div>\n");

    for (var i = 0; i < elm.length; i++) {
        div = div + elm[i];
    }

    $('#vb_command').append(div);



    //黑板宽度
    var bw = $("#vb_command").width();

    //当前字符宽度
    var fs = 30;


    if(px_count > bw - 200){
        line_count += 1;
        px_count = 0;
    }

    document.getElementById("u" + id).style.left =  px_count + "px";
    document.getElementById("u" + id).style.top = py_count + "px";



    //console.log(max);

    var pxdist = 10;

    var col = 100;

    px_count += ( fs * word.length + pxdist );

    if(px_count > bw - 200){
        line_count += 1;
        px_count = 0;
    }

    py_count = col * line_count;




    //$(document.getElementById("w"+id)).offset({top:300,left: divWidth + 20 });


}


//添加句子列表DIV
function NewList(id,st) {

    var div = "";
    var elm = [];

    elm.push("<div class='st_list' id='stl" + id +  "' >");

    elm.push("  <div class='st_list_head' id='stlh" + id +  "' >" + id + "</div>\n");
    elm.push("  <div class='st_list_body' id='stlb" + id +  "' ><span>" + st + "</span></div>\n");
    elm.push("  <div class='st_list_head'  id='stle" + id +  "' >" + "</div>\n");

    elm.push("</div>\n");


    for (var i = 0; i < elm.length; i++) {
        div = div + elm[i];
    }

    $('#listbox').append(div);

}



//截取数字
function GetNum(sid) {
    var RegNom = new RegExp("[^0-9]","g");
    return  sid.replace(RegNom,"");
}


//收集单词数据
function GetAllWords() {

    var wds = [];
    for(var i = 0 ; i < HowManyWords + 1 ; i++){
        var tar = document.getElementById("u" + i);
        var top = tar.style.top.replace("px","");
        var left = tar.style.left.replace("px","");

        var en = document.getElementById("w" + i).title;
        var cn = CNA[i]== null ?"":CNA[i];

        //console.log("en:" + en);
        //console.log("w" + i + "__" + en + "__" + left + "__"  + top );

        var co = COA[i]== null ?8:COA[i];
        var bc = BCA[i]== null ?0:BCA[i];


        wds.push(new Wd(i,en,cn,left,top,co,bc));

    }

    return wds;

}

//展示单词
function ShowWords(DataObj) {

    //$(".word_unit").remove();

    $(".vac_word").parent().remove();


    //$(document.querySelector('div[class^="word_unit"]')).remove();


    var stArr = DataObj.st;
    //var wdArr = DataObj.wd;

    //console.log("DataObj.wd:" + JSON.stringify(DataObj.wd));
    //console.log(DataObj.wd);

    var WordsArr = DataObj.wd;

    HowManyWords = WordsArr.length - 1;

    //清空中文，color,background-color 这三个Array
    CNA = [];
    COA = [];
    BCA = [];


    for(var i = 0 ; i < WordsArr.length; i ++){

        //按英式空格分离出单词，带点标符号
        var WordBlock = WordsArr[i];

        var oder = WordBlock["oder"];
        var en  = WordBlock["en"];
        var cn  = WordBlock["cn"];
        var x   = WordBlock["x"];
        var y   = WordBlock["y"];
        var co = WordBlock["co"];
        var bc = WordBlock["bc"];

        $('#sentence_input').val(stArr[0].en);
        $('#st_cn').val(stArr[0].cn);

        //根据当前字体多少，动态产生相应宽度的DIV容器
        var fontWidth = 50;
        var divWidth = fontWidth * en.length;


        CNA[oder] = WordBlock["cn"]==null?"":WordBlock["cn"];
        COA[oder] = WordBlock["co"]==null?8:WordBlock["co"];
        BCA[oder] = WordBlock["bc"]==null?0:WordBlock["bc"];

        //$(".vac_word").remove();
        NewWord(divWidth,60,en,oder);

        //绑定
        var $tar = $(document.getElementById("u" + oder));
            $tar.draggable({ grid: [ 20, 20 ] });
        //$tar.draggable({ snap: true });

        //设置座标
        var unit = document.getElementById("u" + oder);
            unit.style.left = x + "px";
            unit.style.top = y + "px";

        $(".vac_word").css("font-size",  wd_fontsize[st_cur] + "px" );
        $(".vac_panel").css("font-size",  wd_fontsize[st_cur] + "px" );

        $(document.getElementById("w" + oder)).css("color",color_pen[co]);
        $(document.getElementById("w" + oder)).css("background-color",color_pen[bc]);

        $(document.getElementById("p" + oder)).css("color",color_pen[co]);
        $(document.getElementById("p" + oder)).css("background-color",color_pen[bc]);

    }
}

function Wd(no,en,cn,x,y,co,bc) {
    this.n = no;
    this.e = en;
    this.c = cn;
    this.x  = x;
    this.y  = y;
    this.co = co;
    this.bc = bc;

}

function St(en,cn) {
    this.e = en;
    this.c = cn;
}

